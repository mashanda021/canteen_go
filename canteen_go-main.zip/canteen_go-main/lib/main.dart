import 'package:canteen_go/src/bootstrap.dart';

void main() {
  bootstrap();
}
