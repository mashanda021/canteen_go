package id.ac.unpak.d3mi.canteengo

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
